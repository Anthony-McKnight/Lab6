package edu.monmouth.cs176L.s1249736;
import java.util.ArrayList;
public class StudentList {
	ArrayList <Student> cs176Students;
	 private int count =0;
	 /**
	 * Constructor for StudentList Class
	 */
	 StudentList () {
		 cs176Students = new ArrayList<Student> ();
	 }
	 /**
	 * @param s - new student object
	 */
	 public void addStudent (Student s) {
		 cs176Students.add(s);
	 
	 }
	 /**
		 * @param id
		 * @param year
		 * @return
		 */
	 public boolean updateGraduationYear (String id, Integer year) {
		 boolean result = false;
		 Student student = FindStudentByKey ("studentID",id);
		 if ( student !=null) {
			 student.setGraduationYear(year);
			 return true;
		 }
		 return result;
	 }
	 
	 /**
	 * List the Student using for-each loop
	 */
	 public void listStudents() {
		for (Student s: cs176Students) {
		 	System.out.println(s.toString());
		 	for (Registration r : s.registeredCourses) {
		 		System.out.println(r.toString());
		 	}
		}
	 }
	 /**
		 * @param major
		 * @return
		 */
	 public Integer studentCount(String major) {
	  Integer count=0;
	  for(Student s : cs176Students) {
		  if( s.getMajor() == major) {
			  count++;
		  }	
	  }
	 return count;
	 
	 }
	 public Student FindStudentByKey (String key, String value) {
			Student foundStudent = null;
			String foundValue;
			
			for (Student s: cs176Students) {
				switch (key) {
					case "studentID":
						foundValue = s.getStudentID();
						break;
					case "email" :
						foundValue = s.getEmail();
						break;

					default:
						foundValue = "";
				}
				if (foundValue == value) {
					return s;
				}
			}	
			return foundStudent;	
		}			 	 
		 
	 
	 
	 
	 
	 }

	 
	 