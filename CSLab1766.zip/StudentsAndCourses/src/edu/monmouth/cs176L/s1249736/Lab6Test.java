package edu.monmouth.cs176L.s1249736;

public class Lab6Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
