package edu.monmouth.cs176L.s1249736;

public class Registration {
	public Course course;
	private double grade;

	Registration (Course c, double g){
		this.course = c;
		this.grade = g;
	}
	public void setGrade (double newGrade)
	{
		this.grade= newGrade;
	}
	
	public double getGrade() {
		return this.grade;
	}
	
	public String toString() {
		
		
		return(this.course.toString() + "Grade: " + this.grade);
	}
}
