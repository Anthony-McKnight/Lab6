package edu.monmouth.cs176L.s1249736;

public class Course {
		private String courseCode;
		private String courseNumber;
		private String courseDescription;
		
		Course (String code, String num, String desc) {
			this.courseCode= code;
			this.courseNumber=num;
			this.courseDescription= desc;
		}
		
		
	

}
